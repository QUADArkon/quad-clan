Title    : ProQuake version 3.50
Filename : sqpro350.zip
Version  : 3.50
Date     : September 14, 2002
Author   : J.P. Grossman (a.k.a. Mephistopheles)
Email    : jpg@ai.mit.edu
URL      : http://planetquake.com/proquake

This is the linux release of ProQuake.  sqpro replaces unixeded; use

sqpro -dedicated

to run a dedicated server.  Please see the windows documentation, all of which
applies to sqpro.  The only difference is that the -ip command line option
has been added to squake, i.e. you can specify your IP address with 

-ip <my_ip>

This is useful if your linux box has multiple IP addresses or if its hostname
is not set up correctly (which will cause unixded to core dump).

