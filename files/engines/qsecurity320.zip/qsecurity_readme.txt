Title    : Security Module version 3.20
Filename : qsecurity320.zip
Version  : 3.20
Date     : June 24, 2002
Author   : J.P. Grossman (a.k.a. Mephistopheles)
Email    : jpg@ai.mit.edu
URL      : http://planetquake.com/proquake


This module contains a number of independently developed and tested security
functions related to online network games.

============
Installation
============

Windows users:  

Place qsecurity.dll in the same directory as your game executable

Linux users:

Place qsecurity.so in the same directory as your game executable

================
Acknowledgements
================

Many, many thanks go out to Slot Zero - It would not have been possible to 
port this security module to linux without his help and support.  Thanks
also to Roderick Schertler for providing useful information about linux.


