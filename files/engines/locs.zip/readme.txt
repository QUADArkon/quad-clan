Create a locs subdirectory in your quake\id1 directory put the loc files
there.

