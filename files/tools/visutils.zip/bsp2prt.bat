@echo off
cls
echo"
echo"
echo ---[ Creating PRT Files ]---
echo"
for %%i in (*.bsp) do bsp2prt.exe %%i
echo"
