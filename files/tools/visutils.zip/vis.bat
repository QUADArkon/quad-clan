@echo off
cls
echo"
echo"
echo ---[ VIS-ing BSP Files  ]---
echo"
for %%i in (*.bsp) do vis.exe -level 4 -show %%i
echo"
