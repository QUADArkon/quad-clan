
        ++===========++
        || Map2Curve ||
        ++===========++

        Version: 0.88
       Released: May 2026
         Author: Gibshooter
        Contact: totac@web.de
Discord-Profile: gibshooter
 Discord-Server: https://discord.gg/AWZHf87R5R
        Website: https://gibshooter.com/map2curve/
    Source Code: https://github.com/ToTac/Map2Curve (CLI)

 Special Thanks: Lws, generic, Admer456, Overfloater,
		 JoeFortunell (for his tutorial on the WAD3 format -> http://www.j0e.io),
		 ribcage, Trempler, EnYB0La and others who gave feedback!

   ============= WHAT IT DOES =============

   This program is a brush generator that currently accepts Goldsource map files as input.
   To create a curved version of a map file it can be dragged and dropped onto the Map2Curve executable.
   For this to work the source file has to match certain criteria. Invalid brushes will be ignored.

   WAD information can not be obtained fully automatic. For the program to be able to use your WAD files,
   you have to add the WADs file paths to the WADList.txt in the WAD folder or paste copies of your wad
   files into it. If no texture information could be obtained, the program will use a default texture size
   (128*128), which will lead to bad results, if the actual texture size differs (e.g. 96*32).

   ============= BUG REPORTS =============

   Message me on Discord or via Email, including the specific files
   (map and preset file) and other relevant information (e.g. Operating System).