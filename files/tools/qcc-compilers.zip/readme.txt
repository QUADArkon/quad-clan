***************************************************
****          QUAKEC COMPILERS                 ****
***************************************************

1. DESCRIPTION
==============

This package contains a selection of QuakeC
compilers for Quake.

QuakeC source files (.qc) contain the game logic
used by Quake and its modifications. A QuakeC
compiler processes these source files and produces
the progs.dat file that is loaded by the Quake
engine.

The package includes several generations of QuakeC
compilers, from the original QCC to more advanced
alternative implementations.

Keeping different compilers available is useful
when working with both original Quake source code
and modifications developed with later QuakeC
toolchains.


2. INCLUDED COMPILERS
=====================

QCC
---

The original QuakeC compiler developed for Quake
by id Software.

It represents the original QuakeC compilation
environment and is useful for compiling or testing
source code intended for the original toolchain.


QCCX
----

QuakeC compiler developed by J.P. Grossman
(Mephistopheles).

QCCX extended the traditional QuakeC compiler and
became an important influence on later compilers,
including FrikQCC.


meQCC
-----

QuakeC compiler developed by MrElusive
(Jan Paul van Waveren).

meQCC is based on the original QuakeC compiler and
adds a C-compatible preprocessor.

It can also generate smaller progs.dat files and
provides an option for producing output intended
to be difficult to decompile.


FrikQCC
-------

QuakeC compiler developed by FrikaC.

Originally based on FastQCC and later incorporating
features and ideas from QCCX, FrikQCC provides a
number of extensions to traditional QuakeC.

These include:

    goto and labels
    static variables
    compiler warnings
    additional optimizations

FrikQCC also includes QuakeC decompilation
functionality.


3. BASIC USAGE
==============

Traditional QuakeC projects normally contain a
file named:

    progs.src

together with the required .qc source files.

The progs.src file defines the output file and the
QuakeC source files that must be compiled.

Run the desired compiler against the QuakeC
project.

A successful compilation normally produces:

    progs.dat

The resulting progs.dat should then be placed in
the appropriate Quake game or mod directory.

For example:

    quake\mymod\progs.dat

Quake can then load the compiled game code when
the corresponding game directory is selected.


4. CHOOSING A COMPILER
======================

QCC

Use QCC when working with original QuakeC source
or when compatibility with the original compiler
is important.


QCCX

Useful for older QuakeC projects written or
modified around the QCCX toolchain.


meQCC

Useful when its C-style preprocessing features or
alternative progs.dat generation are required.


FrikQCC

Useful for projects making use of its extended
QuakeC syntax, warnings and optimization features.

It is also useful when QuakeC decompilation
functionality is required.


5. COMPATIBILITY NOTES
======================

Different QuakeC compilers do not necessarily
accept exactly the same source code or generate
identical output.

Older modifications may rely on compiler-specific
syntax, preprocessing behaviour or extensions.

For this reason, when rebuilding historical Quake
mods it is often preferable to try the compiler
originally used by the project before migrating
the code to a different compiler.

Always keep a backup of the original progs.dat
before recompiling an existing modification.


6. CREDITS
==========

QCC
id Software / John Carmack

QCCX
J.P. Grossman (Mephistopheles)

meQCC
MrElusive (Jan Paul van Waveren)

FrikQCC
FrikaC

Individual programs remain the work of their
respective authors and contributors and are
distributed according to their original licenses.


***************************************************
****              HAPPY CODING!                ****
***************************************************