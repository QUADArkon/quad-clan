***************************************************
****             QUAKE TEXTURE WADS            ****
***************************************************

1. DESCRIPTION
==============

This package contains texture WAD files for Quake
and its two official mission packs.

Texture WAD files are used by Quake level editors
to provide the textures required while creating
and editing maps.

The package contains:

    id1.wad
    hipnotic.wad
    rogue.wad


2. INCLUDED WADS
================

id1.wad
-------

Texture collection for the original Quake.

Use this WAD when creating or editing maps based
on the textures from the original game.


hipnotic.wad
------------

Texture collection for Quake Mission Pack No. 1:
Scourge of Armagon.

Use this WAD when working with maps that require
textures from the Hipnotic mission pack.


rogue.wad
---------

Texture collection for Quake Mission Pack No. 2:
Dissolution of Eternity.

Use this WAD when working with maps that require
textures from the Rogue mission pack.


3. BASIC USAGE
==============

Load the required WAD file into a Quake-compatible
level editor.

The textures contained in the WAD will then be
available for use while creating or editing a map.

The appropriate WAD depends on the texture set
required by the map:

    id1.wad      Original Quake
    hipnotic.wad Scourge of Armagon
    rogue.wad    Dissolution of Eternity

More than one WAD may be loaded when supported by
the level editor and required by the map.


4. NOTES
========

Quake texture WAD files are development resources.

They are used by level editors during map creation
and are not game directories or replacement PAK
files.

Textures used by a compiled Quake map are stored
in the BSP, so the original texture WAD is mainly
required when creating or editing the map.

Keep the WAD files available together with your
other Quake mapping resources.


5. CREDITS
==========

Quake
id Software

Mission Pack No. 1: Scourge of Armagon
Hipnotic Interactive

Mission Pack No. 2: Dissolution of Eternity
Rogue Entertainment

All original game artwork and textures remain the
property of their respective copyright holders.


***************************************************
****              HAPPY MAPPING!               ****
***************************************************